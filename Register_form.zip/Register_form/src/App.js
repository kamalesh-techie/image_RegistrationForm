import './App.css';
import RegisterForm from './Components/Task';

function App() {
  return (
    <div className="App">
     <RegisterForm />
    </div>
  );
}

export default App;
